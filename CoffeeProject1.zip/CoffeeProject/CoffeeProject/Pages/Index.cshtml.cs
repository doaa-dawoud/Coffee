using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CoffeeProject.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}
